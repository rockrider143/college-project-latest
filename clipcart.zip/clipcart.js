
 
function form(){
    let f=document.getElementById("login");
 let s= f.getAttribute("hidden");
 if(s!=null){

 f.removeAttribute("hidden");
   
 }
 else{
    f.setAttribute("hidden","");
 }
 
}
function pass(item){
let iq=item.value.length;
let v=document.getElementById("warning");
if(iq==0){
    v.innerHTML="";
    let f=document.getElementById("login");
    f.style.height="200px";
}

else if(iq>0 && iq<6){
    let f=document.getElementById("login");
    f.style.height="230px";
    v.innerHTML="Your password is too small";
}
else if(iq>=6 && iq<=16){

    v.innerHTML="";
    let f=document.getElementById("login");
    f.style.height="200px";
}

else {
    let f=document.getElementById("login");
    f.style.height="250px";
    v.innerHTML="Please Enter a password between 6 to 16 digit";

}
}


